var divsToProcess = document.getElementsByClassName('my');  //получить массив с элементов с классом my

getUnProcessedDiv(divsToProcess);   //вызвать функцию передав туда массив элементов в качестве параметра

function getUnProcessedDiv(elementsArray) {

    //запустить цикл прохода по каждому элементу массива
    //начиная с последнего и идти до нулевого
    for (var i = elementsArray.length - 1; i >= 0; i--) {

        //в переменную сохранить элемент под индексом i
        var currentDiv = elementsArray[i];

        //если свойство backgroundColor не задано
        if (currentDiv.style.backgroundColor === '') {

            //то задать его
            currentDiv.style.backgroundColor = 'orange';

        }
    }
}