var myArray = [3, 5, 8, 13, 21];

console.log("Длина массива:" + myArray.length);

console.log("Элемент с индексов 3:" + myArray[3]);

console.log("Элемент 4: " + myArray[4]);


var complexArray = [[1, 2], null, [5, 6]];
